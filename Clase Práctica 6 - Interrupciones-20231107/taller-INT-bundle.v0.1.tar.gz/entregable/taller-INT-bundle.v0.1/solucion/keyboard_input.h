/* ** por compatibilidad se omiten tildes **
================================================================================
 TALLER System Programming - ORGANIZACION DE COMPUTADOR II - FCEN
================================================================================

  Controlador de teclado minimal
*/

#include <stdint.h>

void process_scancode(uint8_t scancode);
