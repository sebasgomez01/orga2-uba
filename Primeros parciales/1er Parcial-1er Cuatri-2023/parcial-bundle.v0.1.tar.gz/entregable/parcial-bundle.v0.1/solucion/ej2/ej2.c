#include "ej2.h"

void miraQueCoincidencia_c( uint8_t *A, uint8_t *B, uint32_t N, 
                            uint8_t *laCoincidencia ){
}
