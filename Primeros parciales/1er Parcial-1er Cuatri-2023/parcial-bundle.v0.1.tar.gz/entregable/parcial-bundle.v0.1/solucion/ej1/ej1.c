#include "ej1.h"

uint32_t cuantosTemplosClasicos_c(templo *temploArr, size_t temploArr_len){
}
  
templo* templosClasicos_c(templo *temploArr, size_t temploArr_len){
}
