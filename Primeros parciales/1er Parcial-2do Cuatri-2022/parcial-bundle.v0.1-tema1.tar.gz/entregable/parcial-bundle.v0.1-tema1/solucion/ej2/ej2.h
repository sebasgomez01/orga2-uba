#ifndef EJ2_H_
#define EJ2_H_

#include<stdint.h>

int16_t* filtro (const int16_t* entrada, unsigned size);
int16_t* filtro_c (const int16_t* entrada, unsigned size);

#endif //EJ2_H_
